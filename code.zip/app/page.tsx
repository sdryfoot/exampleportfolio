import { Hero } from "@/components/hero"
import { About } from "@/components/about"
import { Projects } from "@/components/projects"
import { FacultyChallenge } from "@/components/faculty-challenge"
import { Contact } from "@/components/contact"
import { Footer } from "@/components/footer"

export default function Home() {
  return (
    <main className="relative">
      <Hero />
      <About />
      <Projects />
      <FacultyChallenge />
      <Contact />
      <Footer />
    </main>
  )
}
