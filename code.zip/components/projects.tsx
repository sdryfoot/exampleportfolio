import { ProjectCard } from "./project-card"

export function Projects() {
  const projects = [
    {
      title: "Student Portfolio Template",
      description:
        "A GitHub Pages starter that makes students look like they know what they're doing. Spoiler: they do.",
      tags: ["GitHub Pages", "Education", "Open Source"],
      link: "#",
    },
    {
      title: "Faculty Tech Toolkit",
      description: "Collection of resources for educators who want to embrace modern tools without losing their minds.",
      tags: ["Resources", "Teaching", "Innovation"],
      link: "#",
    },
    {
      title: "Deeptech for Humans",
      description:
        "Explaining complex technology in words that don't require a PhD to understand. Ironic, given my opening quote.",
      tags: ["Writing", "Education", "Technology"],
      link: "#",
    },
  ]

  return (
    <section id="projects" className="py-20 px-4 bg-secondary/30">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-4xl md:text-5xl font-bold mb-12 text-accent">Projects</h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {projects.map((project, index) => (
            <ProjectCard key={index} {...project} />
          ))}
        </div>
      </div>
    </section>
  )
}
