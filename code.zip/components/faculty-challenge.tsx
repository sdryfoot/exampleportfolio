export function FacultyChallenge() {
  return (
    <section id="challenge" className="py-20 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="relative p-8 md:p-12 bg-gradient-to-br from-primary/20 to-accent/20 border-2 border-accent rounded-lg neon-border">
          <div className="absolute top-4 right-4 text-accent/50 text-sm font-mono">challenge.exe</div>

          <h2 className="text-3xl md:text-4xl font-bold mb-6 text-accent">Faculty Challenge: Let's Do This</h2>

          <div className="space-y-4 text-muted-foreground leading-relaxed">
            <p className="text-lg text-pretty">
              Here's a wild idea: what if we taught students to build their portfolios on GitHub Pages? It's free, it's
              professional, and it teaches them actual skills they'll use in the real world.
            </p>

            <p className="text-lg text-pretty">
              I'm talking version control, web hosting, markdown, and a portfolio that doesn't disappear when they
              graduate. Plus, employers actually look at GitHub. Unlike that one LMS we all pretend to use.
            </p>

            <p className="text-xl font-semibold text-accent text-pretty">
              Let's be honest — if Sam can do it, anyone can.
            </p>

            <p className="text-base text-muted-foreground/80 italic text-pretty">
              (Seriously though, it took me 15 minutes. You've got this.)
            </p>
          </div>

          <div className="mt-8">
            <a
              href="https://pages.github.com"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-block px-6 py-3 bg-accent text-accent-foreground font-semibold rounded-lg hover:bg-accent/90 transition-all hover:shadow-lg hover:shadow-accent/50"
            >
              Learn GitHub Pages →
            </a>
          </div>
        </div>
      </div>
    </section>
  )
}
