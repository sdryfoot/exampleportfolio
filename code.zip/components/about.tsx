export function About() {
  return (
    <section id="about" className="py-20 px-4">
      <div className="max-w-3xl mx-auto">
        <h2 className="text-4xl md:text-5xl font-bold mb-8 text-accent">About</h2>

        <div className="prose prose-invert prose-lg max-w-none">
          <p className="text-muted-foreground leading-relaxed text-pretty">
            I spend my days trying to convince people that technology and education aren't mortal enemies. Spoiler
            alert: they're actually pretty good friends when you introduce them properly.
          </p>

          <p className="text-muted-foreground leading-relaxed text-pretty mt-6">
            As VP at <span className="text-accent font-semibold">ECPI University</span>, I bridge the gap between "we've
            always done it this way" and "wait, we can do that?" I'm passionate about deeptech, practical innovation,
            and making education accessible through tools that students actually want to use. Like GitHub. Which I
            learned 15 minutes ago. Did I mention that already?
          </p>

          <p className="text-muted-foreground leading-relaxed text-pretty mt-6">
            My superpower? Listening. Turns out when you actually hear what students and faculty need, you can build
            things that work. Revolutionary concept, I know.
          </p>
        </div>
      </div>
    </section>
  )
}
