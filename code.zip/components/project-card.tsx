interface ProjectCardProps {
  title: string
  description: string
  tags: string[]
  link: string
}

export function ProjectCard({ title, description, tags, link }: ProjectCardProps) {
  return (
    <a
      href={link}
      className="group block p-6 bg-card border border-border rounded-lg hover:border-accent transition-all duration-300 hover:shadow-lg hover:shadow-accent/20 neon-border"
    >
      <h3 className="text-xl font-bold mb-3 text-foreground group-hover:text-accent transition-colors">{title}</h3>

      <p className="text-muted-foreground leading-relaxed mb-4 text-pretty">{description}</p>

      <div className="flex flex-wrap gap-2">
        {tags.map((tag, index) => (
          <span key={index} className="text-xs px-3 py-1 bg-accent/10 text-accent border border-accent/30 rounded-full">
            {tag}
          </span>
        ))}
      </div>
    </a>
  )
}
