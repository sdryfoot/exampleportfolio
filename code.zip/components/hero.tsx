export function Hero() {
  return (
    <section className="min-h-screen flex flex-col items-center justify-center px-4 py-20 text-center">
      <div className="max-w-4xl mx-auto space-y-8">
        <h1 className="text-5xl md:text-7xl font-bold leading-tight text-balance neon-glow">
          "I do not have a master's or a PhD. Do the academics respect me? Not sure. But I am a great listener."
        </h1>

        <div className="h-px w-24 mx-auto bg-gradient-to-r from-transparent via-accent to-transparent" />

        <p className="text-xl md:text-2xl text-muted-foreground leading-relaxed text-pretty">
          Hi, I'm <span className="text-accent font-semibold">Sam</span> — VP at ECPI University, deeptech enthusiast,
          and education troublemaker. I've known how to make a GitHub Pages site for about 15 minutes, which makes me
          perfectly qualified to suggest a portfolio assignment built here.
        </p>

        <div className="pt-8">
          <a
            href="#about"
            className="inline-block text-accent hover:text-accent/80 transition-colors animate-bounce"
            aria-label="Scroll to about section"
          >
            <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
            </svg>
          </a>
        </div>
      </div>
    </section>
  )
}
