export function Footer() {
  return (
    <footer className="py-12 px-4 border-t border-border">
      <div className="max-w-6xl mx-auto text-center space-y-4">
        <p className="text-muted-foreground text-pretty">
          Built on GitHub Pages in under an hour. 45 minutes were spent asking ChatGPT how.
        </p>

        <p className="text-sm text-muted-foreground/60">
          © {new Date().getFullYear()} Sam Dreyfus. All rights reserved. (Do I need to say that? I learned this 15
          minutes ago.)
        </p>
      </div>
    </footer>
  )
}
